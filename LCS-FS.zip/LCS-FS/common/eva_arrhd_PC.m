
function [arrhd_precision,arrhd_recall,arrhd_distance,arrhd_F1]=eva_arrhd_PC(PC,P,C,UN,trueP,trueC,truePC)


if isempty(truePC)
    if isempty(PC)
        arrhd_precision=1;
        arrhd_recall=1;
        arrhd_distance=0;
        arrhd_F1=1;
    elseif ~isempty(PC)
        arrhd_precision=0;
        arrhd_recall=0;
        arrhd_distance=sqrt(2);
        arrhd_F1=0;
    end
elseif ~isempty(truePC)
    if ~isempty(PC)
        precision1=(length(intersect(P,trueP))+length(intersect(C,trueC)))/length(PC);
        recall1=(length(intersect(P,trueP))+length(intersect(C,trueC)))/length(truePC);
        distance1=sqrt((1-recall1)*(1-recall1)+(1-precision1)*(1-precision1));
        if (precision1+recall1)==0
            f1=0;
        else
            f1=2*precision1*recall1/(precision1+recall1);
        end
        arrhd_precision=precision1;
        arrhd_recall=recall1;
        arrhd_distance=distance1;
        arrhd_F1=f1;
    else
        arrhd_precision=0;
        arrhd_recall=0;
        arrhd_distance=sqrt(2);
        arrhd_F1=0;
    end
end

