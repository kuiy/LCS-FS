function [mean_arrhd_F1]=evaluation_LCS_FS(data,truePC,trueP,trueC,alpha,dataset,threshold,maxK,max_variable)

Algorithm='LCS_FS';

[n,p]=size(data{1});

mean_adj_precision1=[];
mean_adj_recall1=[];
mean_adj_distance1=[];
mean_adj_F11=[];


mean_arrhd_precision1=[];
mean_arrhd_recall1=[];
mean_arrhd_distance1=[];
mean_arrhd_F11=[];


mean_test1=[];
mean_time1=[];


mean_undirected1=[];
mean_reverse1=[];
mean_miss1=[];
mean_extra1=[];
mean_total1=[];

all_PC=cell(10,p);


for j=1%:10
    
    ns=max(data{j});
    
    adj_precision=[];
    adj_recall=[];
    adj_F1=[];
    adj_distance=[];
    
    arrhd_precision=[];
    arrhd_recall=[];
    arrhd_F1=[];
    arrhd_distance=[];
    

    time=[];
    test=[];
    
    undirected=[];
    reverse=[];
    miss=[];
    extra=[];
    total=[];
    
    for i=1:p


        [PC,P,C,UN,ntest,ntime] = LCS_FS(data{j}, ns,i, alpha,threshold,p,maxK);
        

        all_PC{j,i}=PC;

        time=[time,ntime];
        test=[test,ntest];
        
        [adj_pre,adj_rec,adj_dis,adj_F1val]=eva_adj_PC(PC,truePC{i});
        adj_precision=[adj_precision adj_pre];
        adj_recall=[adj_recall adj_rec];
        adj_distance=[adj_distance adj_dis];
        adj_F1=[adj_F1 adj_F1val];
        
        
        [arrhd_pre,arrhd_rec,arrhd_dis,arrhd_F1val]=eva_arrhd_PC(PC,P,C,UN,trueP{i},trueC{i},truePC{i});
        arrhd_precision=[arrhd_precision arrhd_pre];
        arrhd_recall=[arrhd_recall arrhd_rec];
        arrhd_distance=[arrhd_distance arrhd_dis];
        arrhd_F1=[arrhd_F1 arrhd_F1val];
        
        
        G=zeros(p,p); DAG=zeros(p,p);
        
        G(i,trueC{i})=1;   G(trueP{i},i)=1;
        DAG(i,C)=1; DAG(P,i)=1;
        DAG(i,UN)=1;DAG(UN,i)=1;
        
        [nundirected,nreverse,nmiss,nextra,ntotal]=eva_LCS_SHD(G,DAG);
        
        undirected=[undirected,nundirected];
        reverse=[reverse,nreverse];
        miss=[miss,nmiss];
        extra=[extra,nextra];
        total=[total,ntotal];
                
%         i
    end
%     j

    mean_time1=[mean_time1 mean(time)];
    mean_test1=[mean_test1 mean(test)];

    mean_adj_precision1=[mean_adj_precision1 mean(adj_precision)];
    mean_adj_recall1=[mean_adj_recall1 mean(adj_recall)];
    mean_adj_distance1=[mean_adj_distance1 mean(adj_distance)];
    mean_adj_F11=[mean_adj_F11 mean(adj_F1)];
    
    mean_arrhd_precision1=[mean_arrhd_precision1 mean(arrhd_precision)];
    mean_arrhd_recall1=[mean_arrhd_recall1 mean(arrhd_recall)];
    mean_arrhd_distance1=[mean_arrhd_distance1 mean(arrhd_distance)];
    mean_arrhd_F11=[mean_arrhd_F11 mean(arrhd_F1)];
    
    
    mean_undirected1=[mean_undirected1,mean(undirected)];
    mean_reverse1=[mean_reverse1,mean(reverse)];
    mean_miss1=[mean_miss1,mean(miss)];
    mean_extra1=[mean_extra1,mean(extra)];
    mean_total1=[mean_total1,mean(total)];
end

std_time=std(mean_time1);
mean_time=mean(mean_time1);

std_test=std(mean_test1);
mean_test=mean(mean_test1);


std_adj_precision=std(mean_adj_precision1);
std_adj_recall=std(mean_adj_recall1);
std_adj_distance=std(mean_adj_distance1);
std_adj_F1=std(mean_adj_F11);

mean_adj_precision=mean(mean_adj_precision1);
mean_adj_recall=mean(mean_adj_recall1);
mean_adj_distance=mean(mean_adj_distance1);
mean_adj_F1=mean(mean_adj_F11);




std_arrhd_precision=std(mean_arrhd_precision1);
std_arrhd_recall=std(mean_arrhd_recall1);
std_arrhd_distance=std(mean_arrhd_distance1);
std_arrhd_F1=std(mean_arrhd_F11);

mean_arrhd_precision=mean(mean_arrhd_precision1);
mean_arrhd_recall=mean(mean_arrhd_recall1);
mean_arrhd_distance=mean(mean_arrhd_distance1);
mean_arrhd_F1=mean(mean_arrhd_F11);




std_undirected=std(mean_undirected1);
std_reverse=std(mean_reverse1);
std_miss=std(mean_miss1);
std_extra=std(mean_extra1);
std_total=std(mean_total1);

mean_undirected=mean(mean_undirected1);
mean_reverse=mean(mean_reverse1);
mean_miss=mean(mean_miss1);
mean_extra=mean(mean_extra1);
mean_total=mean(mean_total1);




fprintf('\nadj_F1\nadj_distance\tadj_precision\tadj_recall\ttest\ttime\n');
fprintf('%.2f+%.2f\n',mean_adj_F1,std_adj_F1);
fprintf('%.2f+%.2f\t%.2f+%.2f\t%.2f+%.2f\t%.2f+%.2f\t%.2f+%.2f\n\n',mean_adj_distance,std_adj_distance,mean_adj_precision,std_adj_precision,mean_adj_recall,std_adj_recall,mean_test,std_test,mean_time,std_time);

fprintf('arrhd_F1\narrhd_distance\tarrhd_precision\tarrhd_recall\ttest\ttime\n');
fprintf('%.2f+%.2f\n',mean_arrhd_F1,std_arrhd_F1);
fprintf('%.2f+%.2f\t%.2f+%.2f\t%.2f+%.2f\t%.2f+%.2f\t%.2f+%.2f\n\n',mean_arrhd_distance,std_arrhd_distance,mean_arrhd_precision,std_arrhd_precision,mean_arrhd_recall,std_arrhd_recall,mean_test,std_test,mean_time,std_time);

fprintf('total\tundirected\treverse\tmiss\textra\ttest\ttime\t\n%.2f+%.2f\t',mean_total,std_total);
fprintf('%.2f+%.2f\t%.2f+%.2f\t%.2f+%.2f\t%.2f+%.2f\t%.2f+%.2f\t%.2f+%.2f\t\n\n\n',mean_undirected,std_undirected,mean_reverse,std_reverse,mean_miss,std_miss,mean_extra,std_extra,mean_test,std_test,mean_time,std_time);


