
function [nundirected,nreverse,nmiss,nextra,ntotal]=eva_LCS_SHD(G,DAG)



diff_G=G-DAG;
[x,y]=find(diff_G~=0);

nundirected=0;
nreverse=0;
nmiss=0;
nextra=0;
ntotal=0;

for loop_i=1:length(x)
    
    if x(loop_i)==-1
        continue;
    end
    biaozhi=0;
    
    if ~isempty(find(y==(x(loop_i)), 1))
        y_index=find(y==(x(loop_i)));
        for k=1:length(y_index)
            if x(y_index(k))==y(loop_i)
                
                biaozhi=1;
                if G(x(loop_i),y(loop_i))==G(x(y_index(k)),y(y_index(k)))
                    nextra=nextra+1;
                else
                    nreverse=nreverse+1;
                    
                end
                x(y_index(k))=-1;
                y(y_index(k))=-1;
                break;
                
            end
        end
    end
    if biaozhi==0
        if G(y(loop_i),x(loop_i))==0
            if G(x(loop_i),y(loop_i))==1
                nmiss=nmiss+1;
                
            else
                nextra=nextra+1;
                
            end
        else
            nundirected=nundirected+1;
        end
    end
end


ntotal=nextra+nmiss+nreverse+nundirected;




