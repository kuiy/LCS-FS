
function [adj_precision,adj_recall,adj_distance,adj_F1]=eva_adj_PC(PC,truePC)



if isempty(truePC)
    if isempty(PC)
        adj_precision=1;
        adj_recall=1;
        adj_distance=0;
        adj_F1=1;
    elseif ~isempty(PC)
        adj_precision=0;
        adj_recall=0;
        adj_distance=sqrt(2);
        adj_F1=0;
    end
elseif ~isempty(truePC)
    if ~isempty(PC)
        precision1=length(intersect(PC,truePC))/length(PC);
        recall1=length(intersect(PC,truePC))/length(truePC);
        distance1=sqrt((1-recall1)*(1-recall1)+(1-precision1)*(1-precision1));
        if (precision1+recall1)==0
            f1=0;
        else
            f1=2*precision1*recall1/(precision1+recall1);
        end
        adj_precision=precision1;
        adj_recall=recall1;
        adj_distance=distance1;
        adj_F1=f1;
    else
        adj_precision=0;
        adj_recall=0;
        adj_distance=sqrt(2);
        adj_F1=0;
    end
end

