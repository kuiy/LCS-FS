
function   [pc,ntest,time]=PC_FS_FCBF(Data,target,p,threshold)


start=tic;


ntest=0;

train_data=Data(:,mysetdiff(1:p,target));
train_label=Data(:,target);


% yingshe=unique([1:target-1,target+1:p]);


if target~=p 
    yingshe=unique([1:target-1,target+1:p]);
else
    yingshe=1:target;
end

[FCBF_PC,ntest_PC]=FCBF(train_data,train_label,threshold);

ntest=ntest+ntest_PC;

pc=sort(yingshe(FCBF_PC));

time=toc(start);





