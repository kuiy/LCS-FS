

addpath(genpath('common'));


clc;
clear;
close;

        
alpha = 0.01;
maxK=3;

max_variable=0;

dataset='alarm';    dataset2='Alarm1';


num=10;
data=cell(1,num);

for i=1:num
    data_str=strcat('data/Alarm1_s1000_v',num2str(i),'.txt');
    data{i} = importdata(data_str)+1;
end


graph_str=strcat('data/Alarm1_graph.txt');
graph_data=importdata(graph_str);


[trueMB,trueP,trueC,truePC,trueSP,p]= STA(graph_data);
       
disp('LCS_FS')
threshold=0.05;
[mean_arrhd_F1]=evaluation_LCS_FS(data,truePC,trueP,trueC,alpha,dataset,threshold,maxK,max_variable);






