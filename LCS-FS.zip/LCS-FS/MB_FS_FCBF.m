
function   [mb,ntest,time]=MB_FS_FCBF(Data,target,alpha,ns,p,k,threshold)


start=tic;


ntest=0;

[pc,ntest1]=PC_FS_FCBF(Data,target,p,threshold);
ntest=ntest+ntest1;

mb=pc;

for i=1:length(pc)
    [pc_tmp,ntest2]=PC_FS_FCBF(Data,pc(i),p,threshold);
    ntest=ntest+ntest2;

    for j=1:length(pc_tmp)
        
        if ismember(pc_tmp(j),pc)||pc_tmp(j)==target
            continue;
        end
                
        CanPC=pc;
        cutSetSize = 0;
        
        break_flag=0;

        while length(CanPC) >= cutSetSize &&cutSetSize<=k
            
            SS = subsets1(CanPC, cutSetSize);    % all subsets of size cutSetSize
            for si=1:length(SS)
                Z = SS{si};

                ntest=ntest+1;
                pval=my_g2test(pc_tmp(j),target,Z,Data,ns);
                
                if pval>alpha
                    
                    if ~ismember(pc(i),Z)
                        ntest=ntest+1;
                        pval=my_g2test(pc_tmp(j),target,myunion(Z,pc(i)),Data,ns);
                        
                        if isnan(pval)||pval<=alpha
                            mb=myunion(mb,pc_tmp(j));
                        end
                    end
                    
                    break_flag=1;
                    break;
                end
            end
            if break_flag
                break;
            end
            cutSetSize = cutSetSize + 1;
        end
        
    end
end




time=toc(start);





